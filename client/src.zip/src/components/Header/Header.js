import React from 'react';

import classes from './Header.module.scss';

const header = () => {
    return <div className={classes.Header}>HEADER</div>;
};

export default header;
